import React, { useState, useEffect } from 'react';
import { 
  Printer, 
  Wifi, 
  Battery, 
  Bell, 
  Check, 
  CheckCircle, 
  LogOut, 
  Mail, 
  Lock, 
  Store, 
  Play, 
  Pause, 
  FileDown, 
  Clock, 
  RefreshCw, 
  ChevronRight,
  ExternalLink,
  Sliders,
  CheckCircle2,
  Trash2,
  Sparkles,
  Zap,
  Radio
} from 'lucide-react';
import { OrderData, ReceiptModal } from './ReceiptModal';

interface PhoneSimulatorProps {
  onSimulateOrderTrigger?: () => void;
  activeOrderJob?: {
    stage: 'idle' | 'detected' | 'downloading' | 'printing' | 'firestore_updated' | 'cleanup_scheduled';
    orderId?: string;
    progress?: number;
  };
}

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({
  onSimulateOrderTrigger,
  activeOrderJob,
}) => {
  // App state
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [email, setEmail] = useState('shopkeeper@shashiprint.com');
  const [password, setPassword] = useState('••••••••••••');
  const [shopId, setShopId] = useState('SHOP_PATNA_01');
  const [tempShopId, setTempShopId] = useState('SHOP_PATNA_01');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Main screen controls
  const [autoPrintEnabled, setAutoPrintEnabled] = useState(true);
  const [connectedPrinter, setConnectedPrinter] = useState('POS-80 Thermal USB/BT');
  const [isChangingPrinter, setIsChangingPrinter] = useState(false);
  const [notificationExpanded, setNotificationExpanded] = useState(false);

  // Selected receipt to view
  const [selectedReceipt, setSelectedReceipt] = useState<OrderData | null>(null);

  // Orders list (Initial 4 orders, ready to add more)
  const [orders, setOrders] = useState<OrderData[]>([
    {
      id: 'ord_984102',
      customerName: 'Aarav Sharma',
      totalAmount: 140,
      itemsSummary: '10x Color Prints + 2x Lamination',
      status: 'paid',
      printed: true,
      printedAt: '10:42 AM, Today',
      pdfUrl: 'https://firebasestorage.googleapis.com/.../Order_984102.pdf',
      items: [
        { name: 'Color A4 Photo Print', qty: 10, price: 100 },
        { name: 'Glossy Lamination', qty: 2, price: 40 },
      ],
    },
    {
      id: 'ord_984098',
      customerName: 'Pooja Verma',
      totalAmount: 45,
      itemsSummary: 'Spiral Notebook Binding',
      status: 'paid',
      printed: true,
      printedAt: '10:35 AM, Today',
      pdfUrl: 'https://firebasestorage.googleapis.com/.../Order_984098.pdf',
      items: [
        { name: 'Spiral Binding (100 pgs)', qty: 1, price: 45 },
      ],
    },
    {
      id: 'ord_984089',
      customerName: 'Vikram Singh',
      totalAmount: 220,
      itemsSummary: 'Resume 5 sets + ID Card PVC Print',
      status: 'paid',
      printed: true,
      printedAt: '10:18 AM, Today',
      pdfUrl: 'https://firebasestorage.googleapis.com/.../Order_984089.pdf',
      items: [
        { name: 'Resume Laser Print', qty: 5, price: 50 },
        { name: 'PVC Smart Card Printing', qty: 2, price: 170 },
      ],
    },
    {
      id: 'ord_984065',
      customerName: 'Deepak Kumar',
      totalAmount: 90,
      itemsSummary: '30x Xerox Document Copies',
      status: 'paid',
      printed: true,
      printedAt: '09:55 AM, Today',
      pdfUrl: 'https://firebasestorage.googleapis.com/.../Order_984065.pdf',
      items: [
        { name: 'B&W Xerox Duplex', qty: 30, price: 90 },
      ],
    },
    {
      id: 'ord_984042',
      customerName: 'Suman Roy',
      totalAmount: 180,
      itemsSummary: 'A3 Poster Glossy Print x2',
      status: 'paid',
      printed: true,
      printedAt: '09:20 AM, Today',
      pdfUrl: 'https://firebasestorage.googleapis.com/.../Order_984042.pdf',
      items: [
        { name: 'A3 Glossy Poster Print', qty: 2, price: 180 },
      ],
    },
  ]);

  // Live order processing state simulation
  const [pipelineState, setPipelineState] = useState<{
    active: boolean;
    orderId: string;
    step: 'detected' | 'downloading' | 'printing' | 'updated' | 'cleanup_timer' | 'done';
    progress: number;
    timerSeconds: number;
  }>({
    active: false,
    orderId: '',
    step: 'done',
    progress: 0,
    timerSeconds: 60,
  });

  // Handle Login submission
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempShopId.trim()) {
      setLoginError('Please specify your Shop ID');
      return;
    }
    setLoginError(null);
    setIsLoggingIn(true);
    setTimeout(() => {
      setIsLoggingIn(false);
      setShopId(tempShopId.trim().toUpperCase());
      setIsLoggedIn(true);
    }, 700);
  };

  // Quick fill sample credentials
  const handleQuickFill = () => {
    setEmail('patna_central@shashiprint.com');
    setPassword('printMaster#2026');
    setTempShopId('SHOP_PATNA_01');
    setLoginError(null);
  };

  // Trigger simulated incoming order
  const triggerSimulatedOrder = () => {
    if (!autoPrintEnabled) {
      alert('Auto-Print is currently Paused. Toggle Auto-Print ON to process new orders.');
      return;
    }

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const newOrderId = `ord_98${randomSuffix}`;
    const customers = ['Ananya Gupta', 'Rohan Mehta', 'Sneha Patel', 'Manoj Bajpai', 'Kavita Joshi'];
    const chosenCustomer = customers[Math.floor(Math.random() * customers.length)];
    const amounts = [120, 85, 260, 195, 310];
    const chosenAmount = amounts[Math.floor(Math.random() * amounts.length)];

    const now = new Date();
    const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ', Today';

    setPipelineState({
      active: true,
      orderId: newOrderId,
      step: 'detected',
      progress: 20,
      timerSeconds: 60,
    });

    // Step 2: DownloadManager PDF
    setTimeout(() => {
      setPipelineState(prev => ({ ...prev, step: 'downloading', progress: 50 }));
    }, 1100);

    // Step 3: PrintManager spooling
    setTimeout(() => {
      setPipelineState(prev => ({ ...prev, step: 'printing', progress: 80 }));
    }, 2400);

    // Step 4: Printed & Firestore updated
    setTimeout(() => {
      setPipelineState(prev => ({ ...prev, step: 'updated', progress: 100 }));

      // Add to front of order list (keeping last 5)
      const newOrder: OrderData = {
        id: newOrderId,
        customerName: chosenCustomer,
        totalAmount: chosenAmount,
        itemsSummary: 'Order Invoice PDF · Instant Spool',
        status: 'paid',
        printed: true,
        printedAt: timeString,
        pdfUrl: `https://firebasestorage.googleapis.com/.../Order_${newOrderId}.pdf`,
        items: [
          { name: 'Standard Printing Job', qty: 1, price: chosenAmount - 40 },
          { name: 'Thermal Receipt Processing', qty: 1, price: 40 },
        ],
      };

      setOrders(prev => [newOrder, ...prev.slice(0, 4)]);
    }, 3800);

    // Step 5: WorkManager scheduled cleanup countdown
    setTimeout(() => {
      setPipelineState(prev => ({ ...prev, step: 'cleanup_timer' }));
    }, 5000);
  };

  // Timer countdown for WorkManager cleanup
  useEffect(() => {
    let interval: any;
    if (pipelineState.active && pipelineState.step === 'cleanup_timer' && pipelineState.timerSeconds > 0) {
      interval = setInterval(() => {
        setPipelineState(prev => {
          if (prev.timerSeconds <= 1) {
            return { ...prev, step: 'done', active: false, timerSeconds: 60 };
          }
          return { ...prev, timerSeconds: prev.timerSeconds - 1 };
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [pipelineState.active, pipelineState.step, pipelineState.timerSeconds]);

  return (
    <div className="flex flex-col xl:flex-row gap-8 items-center xl:items-start justify-center w-full">
      {/* ================= ANDROID PHONE CHASSIS ================= */}
      <div className="relative w-[360px] sm:w-[380px] h-[760px] bg-slate-950 rounded-[48px] p-3 shadow-2xl ring-1 ring-slate-800 border-[6px] border-slate-900 select-none flex flex-col shrink-0">
        {/* Dynamic camera punch hole & speaker */}
        <div className="absolute top-5 left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-full z-40 flex items-center justify-center gap-3">
          <div className="w-3 h-3 bg-slate-900 rounded-full border border-slate-800" />
          <div className="w-1.5 h-1.5 bg-blue-950/70 rounded-full" />
        </div>

        {/* Outer Phone Display screen */}
        <div className="relative w-full h-full bg-[#F8FAFC] rounded-[38px] overflow-hidden flex flex-col">
          {/* Android Status Bar */}
          <div className="h-10 bg-[#EC4899] text-white px-6 flex items-center justify-between text-xs font-semibold z-30 pt-1 shrink-0">
            <span>10:45</span>
            <div className="flex items-center gap-2">
              <Radio className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <div className="flex items-center gap-0.5">
                <span className="text-[10px]">98%</span>
                <Battery className="w-4 h-4 fill-white" />
              </div>
            </div>
          </div>

          {/* Sticky Foreground Service Notification Banner (Android System Shade) */}
          {isLoggedIn && (
            <div className="bg-slate-900 text-white px-3.5 py-2 text-xs border-b border-slate-800 shrink-0 shadow-sm transition-all">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="font-semibold text-[11px] text-pink-200">
                    Shashi Print Agent - Active
                  </span>
                </div>
                <button
                  onClick={() => setNotificationExpanded(!notificationExpanded)}
                  className="text-[10px] text-slate-400 hover:text-white"
                >
                  {notificationExpanded ? 'Collapse' : 'Details'}
                </button>
              </div>
              {notificationExpanded && (
                <div className="mt-1.5 pt-1.5 border-t border-slate-800 text-[10px] text-slate-300 space-y-0.5">
                  <p>• Foreground Service (dataSync) running</p>
                  <p>• Listening: shops/{shopId}/orders [status=paid, printed=false]</p>
                  <p>• Target Spooler: {connectedPrinter}</p>
                </div>
              )}
            </div>
          )}

          {/* MAIN SCREEN BODY */}
          <div className="flex-1 overflow-y-auto flex flex-col">
            {!isLoggedIn ? (
              /* ================= LOGIN SCREEN ================= */
              <div className="flex-1 p-5 flex flex-col justify-center animate-in fade-in duration-200">
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 flex flex-col items-center text-center">
                  {/* Pink Circle Logo */}
                  <div className="w-16 h-16 rounded-full bg-[#EC4899] flex items-center justify-center text-white shadow-md shadow-pink-200 mb-4">
                    <Printer className="w-8 h-8" />
                  </div>

                  <h2 className="text-xl font-bold text-slate-900">Shashi Print Agent</h2>
                  <p className="text-xs text-slate-500 mt-1">Shopkeeper POS Auto-Print Terminal</p>

                  <form onSubmit={handleLogin} className="w-full mt-6 space-y-3.5 text-left">
                    <div>
                      <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                        Shop ID (Saved locally)
                      </label>
                      <div className="relative">
                        <Store className="w-4 h-4 text-[#EC4899] absolute left-3 top-3" />
                        <input
                          type="text"
                          value={tempShopId}
                          onChange={e => setTempShopId(e.target.value)}
                          placeholder="e.g. SHOP_PATNA_01"
                          className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#EC4899] font-medium uppercase"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                        Shopkeeper Email
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-[#EC4899] absolute left-3 top-3" />
                        <input
                          type="email"
                          value={email}
                          onChange={e => setEmail(e.target.value)}
                          placeholder="shop@shashiprint.com"
                          className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#EC4899]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                        Password
                      </label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-[#EC4899] absolute left-3 top-3" />
                        <input
                          type="password"
                          value={password}
                          onChange={e => setPassword(e.target.value)}
                          placeholder="••••••••••••"
                          className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#EC4899]"
                        />
                      </div>
                    </div>

                    {loginError && (
                      <p className="text-[11px] text-red-500 font-medium">{loginError}</p>
                    )}

                    <button
                      type="submit"
                      disabled={isLoggingIn}
                      className="w-full mt-2 py-3 bg-[#EC4899] text-white rounded-xl text-xs font-semibold shadow-md shadow-pink-200 hover:bg-[#db2777] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                    >
                      {isLoggingIn ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Connecting Firebase...</span>
                        </>
                      ) : (
                        <span>Sign In & Launch Agent</span>
                      )}
                    </button>
                  </form>

                  <button
                    type="button"
                    onClick={handleQuickFill}
                    className="mt-4 text-[11px] text-[#EC4899] hover:underline font-medium"
                  >
                    Use Sample Demo Credentials
                  </button>
                </div>
              </div>
            ) : (
              /* ================= MAIN DASHBOARD SCREEN ================= */
              <div className="flex-1 flex flex-col pb-4">
                {/* Top Material 3 App Bar */}
                <div className="bg-[#EC4899] text-white px-4 py-3 flex items-center justify-between shadow-sm">
                  <div>
                    <h1 className="font-bold text-base leading-tight">Shashi Print Agent</h1>
                    <div className="flex items-center gap-1.5 text-[11px] text-pink-100">
                      <span>Shop ID:</span>
                      <span className="font-semibold">{shopId}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsLoggedIn(false)}
                    title="Sign Out"
                    className="p-1.5 rounded-full hover:bg-white/20 transition-colors"
                  >
                    <LogOut className="w-4 h-4 text-white" />
                  </button>
                </div>

                {/* Main Content Area */}
                <div className="p-3.5 space-y-3 flex-1">
                  {/* Card 1: Agent Status with Pulsing Green Dot */}
                  <div className="bg-white rounded-2xl p-3.5 shadow-sm border border-slate-100 flex items-center gap-3">
                    <div className="relative flex items-center justify-center">
                      {autoPrintEnabled ? (
                        <>
                          <span className="animate-ping absolute inline-flex h-4 w-4 rounded-full bg-emerald-400 opacity-75" />
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
                        </>
                      ) : (
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-400" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-xs text-slate-900 leading-snug">
                        {autoPrintEnabled
                          ? 'Agent Active - Waiting for Orders...'
                          : 'Agent Paused - Auto-Print Off'}
                      </h3>
                      <p className="text-[10px] text-slate-500 truncate">
                        Firestore sync · shops/{shopId}/orders
                      </p>
                    </div>
                  </div>

                  {/* Card 2: Connected Printer Card */}
                  <div className="bg-white rounded-2xl p-3.5 shadow-sm border border-slate-100 space-y-2 relative overflow-hidden">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-pink-50 text-[#EC4899] flex items-center justify-center shrink-0">
                          <Printer className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500 font-medium">Connected Printer</p>
                          <p className="text-xs font-bold text-slate-800">{connectedPrinter}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setIsChangingPrinter(!isChangingPrinter)}
                        className="text-[11px] font-semibold text-[#EC4899] hover:underline"
                      >
                        Change
                      </button>
                    </div>

                    {/* Printer switch selection menu */}
                    {isChangingPrinter && (
                      <div className="pt-2 border-t border-slate-100 space-y-1.5 animate-in fade-in duration-150">
                        {[
                          'POS-80 Thermal USB/BT',
                          'HP LaserJet Pro M404dn (Network IP)',
                          'Epson TM-T88VI Receipt Printer',
                          'Generic Bluetooth ESC/POS 58mm',
                        ].map(pName => (
                          <button
                            key={pName}
                            onClick={() => {
                              setConnectedPrinter(pName);
                              setIsChangingPrinter(false);
                            }}
                            className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] flex items-center justify-between transition-colors ${
                              connectedPrinter === pName
                                ? 'bg-pink-50 text-[#EC4899] font-bold'
                                : 'hover:bg-slate-50 text-slate-700'
                            }`}
                          >
                            <span>{pName}</span>
                            {connectedPrinter === pName && <Check className="w-3.5 h-3.5" />}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Card 3: Toggle: Auto-Print ON/OFF */}
                  <div className="bg-white rounded-2xl p-3.5 shadow-sm border border-slate-100 flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-xs text-slate-800">Auto-Print Mode</h4>
                      <p className="text-[10px] text-slate-500">
                        {autoPrintEnabled ? 'Prints automatically on paid status' : 'Printing is paused'}
                      </p>
                    </div>
                    {/* Material 3 Styled Switch */}
                    <button
                      type="button"
                      role="switch"
                      aria-checked={autoPrintEnabled}
                      onClick={() => setAutoPrintEnabled(!autoPrintEnabled)}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        autoPrintEnabled ? 'bg-[#EC4899]' : 'bg-slate-300'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                          autoPrintEnabled ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Card 4: List of Last 5 Printed Orders */}
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between px-1">
                      <h3 className="font-bold text-xs text-slate-800">Last 5 Printed Orders</h3>
                      <span className="text-[10px] text-slate-500">Auto-Spool</span>
                    </div>

                    <div className="space-y-2">
                      {orders.map(order => (
                        <div
                          key={order.id}
                          onClick={() => setSelectedReceipt(order)}
                          className="bg-white rounded-xl p-3 shadow-sm border border-slate-100 hover:border-pink-200 cursor-pointer transition-all active:scale-[0.99] flex items-center gap-3"
                        >
                          <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                            <Check className="w-4 h-4 stroke-[3]" />
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-xs text-slate-900 truncate">
                                #{order.id.slice(-6).toUpperCase()}
                              </span>
                              <span className="font-bold text-xs text-[#EC4899]">
                                ₹{order.totalAmount}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-600 truncate">{order.customerName}</p>
                            <div className="flex items-center justify-between text-[10px] text-slate-400 mt-0.5">
                              <span>{order.printedAt}</span>
                              <span className="text-pink-600 hover:underline">View Slip →</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Android Bottom Navigation Bar */}
          <div className="h-12 bg-white border-t border-slate-100 flex items-center justify-around px-8 shrink-0">
            <div className="w-3.5 h-3.5 border-2 border-slate-400 rounded-sm" />
            <div className="w-3.5 h-3.5 rounded-full border-2 border-slate-400" />
            <div className="w-0 h-0 border-y-[6px] border-y-transparent border-r-[10px] border-r-slate-400" />
          </div>
        </div>
      </div>

      {/* ================= COMPANION SIMULATOR & WORKFLOW CONTROLS ================= */}
      <div className="flex-1 max-w-xl space-y-5">
        {/* Quick Simulator Controller Card */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <span>Real-Time Agent Simulation</span>
                <span className="bg-pink-100 text-[#EC4899] text-[11px] font-bold px-2 py-0.5 rounded-full">
                  Live
                </span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Test the background pipeline from Firestore trigger to physical PrintManager spool
              </p>
            </div>
          </div>

          <div className="mt-4 space-y-4">
            <button
              onClick={triggerSimulatedOrder}
              disabled={pipelineState.active && pipelineState.step !== 'cleanup_timer'}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#EC4899] to-[#db2777] text-white font-bold text-sm shadow-lg shadow-pink-200 hover:shadow-pink-300 hover:from-[#db2777] hover:to-[#be185d] active:scale-[0.98] transition-all flex items-center justify-center gap-2.5 disabled:opacity-50"
            >
              <Zap className="w-5 h-5 fill-white" />
              <span>Simulate Customer Paid Order (Trigger Firestore doc)</span>
            </button>

            {/* Pipeline Stage Tracker */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-700">Android Background Workflow:</span>
                <span className="font-mono text-[11px] text-[#EC4899]">
                  {pipelineState.active
                    ? `Processing ${pipelineState.orderId}`
                    : 'Standing by for Firestore changes'}
                </span>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-[#EC4899] h-full transition-all duration-500"
                  style={{
                    width: pipelineState.active ? `${pipelineState.progress}%` : '0%',
                  }}
                />
              </div>

              {/* Step checklist */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {/* Step 1 */}
                <div
                  className={`flex items-start gap-2 p-2 rounded-xl transition-colors ${
                    pipelineState.active && ['detected', 'downloading', 'printing', 'updated', 'cleanup_timer'].includes(pipelineState.step)
                      ? 'bg-pink-50/80 text-pink-900 font-medium'
                      : 'text-slate-400'
                  }`}
                >
                  <CheckCircle2
                    className={`w-4 h-4 mt-0.5 shrink-0 ${
                      pipelineState.active && ['detected', 'downloading', 'printing', 'updated', 'cleanup_timer'].includes(pipelineState.step)
                        ? 'text-[#EC4899]'
                        : 'text-slate-300'
                    }`}
                  />
                  <div>
                    <span className="font-semibold block">1. Firestore Snapshot</span>
                    <span className="text-[10px] text-slate-500">status="paid", printed=false</span>
                  </div>
                </div>

                {/* Step 2 */}
                <div
                  className={`flex items-start gap-2 p-2 rounded-xl transition-colors ${
                    pipelineState.active && ['downloading', 'printing', 'updated', 'cleanup_timer'].includes(pipelineState.step)
                      ? 'bg-pink-50/80 text-pink-900 font-medium'
                      : 'text-slate-400'
                  }`}
                >
                  <CheckCircle2
                    className={`w-4 h-4 mt-0.5 shrink-0 ${
                      pipelineState.active && ['downloading', 'printing', 'updated', 'cleanup_timer'].includes(pipelineState.step)
                        ? 'text-[#EC4899]'
                        : 'text-slate-300'
                    }`}
                  />
                  <div>
                    <span className="font-semibold block">2. DownloadManager PDF</span>
                    <span className="text-[10px] text-slate-500">To /Download/ShashiPrint/</span>
                  </div>
                </div>

                {/* Step 3 */}
                <div
                  className={`flex items-start gap-2 p-2 rounded-xl transition-colors ${
                    pipelineState.active && ['printing', 'updated', 'cleanup_timer'].includes(pipelineState.step)
                      ? 'bg-pink-50/80 text-pink-900 font-medium'
                      : 'text-slate-400'
                  }`}
                >
                  <CheckCircle2
                    className={`w-4 h-4 mt-0.5 shrink-0 ${
                      pipelineState.active && ['printing', 'updated', 'cleanup_timer'].includes(pipelineState.step)
                        ? 'text-[#EC4899]'
                        : 'text-slate-300'
                    }`}
                  />
                  <div>
                    <span className="font-semibold block">3. Android PrintManager</span>
                    <span className="text-[10px] text-slate-500">Spool via PrintDocumentAdapter</span>
                  </div>
                </div>

                {/* Step 4 */}
                <div
                  className={`flex items-start gap-2 p-2 rounded-xl transition-colors ${
                    pipelineState.active && ['updated', 'cleanup_timer'].includes(pipelineState.step)
                      ? 'bg-pink-50/80 text-pink-900 font-medium'
                      : 'text-slate-400'
                  }`}
                >
                  <CheckCircle2
                    className={`w-4 h-4 mt-0.5 shrink-0 ${
                      pipelineState.active && ['updated', 'cleanup_timer'].includes(pipelineState.step)
                        ? 'text-[#EC4899]'
                        : 'text-slate-300'
                    }`}
                  />
                  <div>
                    <span className="font-semibold block">4. Firestore Status Update</span>
                    <span className="text-[10px] text-slate-500">printed=true, printedAt=now</span>
                  </div>
                </div>
              </div>

              {/* WorkManager Countdown Banner */}
              {pipelineState.step === 'cleanup_timer' && (
                <div className="mt-2 p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-center justify-between text-xs text-amber-900 animate-in fade-in">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-600 animate-spin" />
                    <span>
                      WorkManager: PDF cleanup scheduled in{' '}
                      <strong>{pipelineState.timerSeconds}s</strong>
                    </span>
                  </div>
                  <span className="text-[10px] bg-amber-200/60 font-mono px-2 py-0.5 rounded-md">
                    DeleteFileWorker
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Feature Highlights Checklist Card */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-4">
          <h3 className="font-bold text-sm text-slate-900">
            Native Android Implementation Specs
          </h3>
          <ul className="space-y-2.5 text-xs text-slate-600">
            <li className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-pink-100 text-[#EC4899] flex items-center justify-center shrink-0 font-bold text-[10px]">
                1
              </span>
              <div>
                <strong className="text-slate-800">Shopkeeper Login & Local ShopID</strong>: Uses Firebase Auth (Email/Pass) with automatic session save in Android SharedPreferences for offline resilience.
              </div>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-pink-100 text-[#EC4899] flex items-center justify-center shrink-0 font-bold text-[10px]">
                2
              </span>
              <div>
                <strong className="text-slate-800">Foreground Service & Sticky Notification</strong>: Runs <code className="text-[#EC4899] bg-pink-50 px-1 py-0.5 rounded font-mono">PrintForegroundService</code> with notification channel and <code className="font-mono">START_STICKY</code> to prevent OS task killer termination.
              </div>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-pink-100 text-[#EC4899] flex items-center justify-center shrink-0 font-bold text-[10px]">
                3
              </span>
              <div>
                <strong className="text-slate-800">Firestore Real-time Snapshot Query</strong>:
                <div className="mt-1 font-mono text-[10px] bg-slate-900 text-pink-200 p-2 rounded-lg overflow-x-auto">
                  collection("shops").document(SHOP_ID).collection("orders")<br/>
                  &nbsp;&nbsp;.whereEqualTo("status", "paid")<br/>
                  &nbsp;&nbsp;.whereEqualTo("printed", false)
                </div>
              </div>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-pink-100 text-[#EC4899] flex items-center justify-center shrink-0 font-bold text-[10px]">
                4
              </span>
              <div>
                <strong className="text-slate-800">Automatic PDF Spooling</strong>: Downloads via Android <code className="text-slate-800 font-mono">DownloadManager</code> to <code className="font-mono">/Download/ShashiPrint/</code> and dispatches directly to system <code className="text-slate-800 font-mono">PrintManager</code> using custom <code className="text-slate-800 font-mono">PdfPrintDocumentAdapter</code>.
              </div>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-pink-100 text-[#EC4899] flex items-center justify-center shrink-0 font-bold text-[10px]">
                5
              </span>
              <div>
                <strong className="text-slate-800">60-Second Delayed WorkManager Cleanup</strong>: Enqueues <code className="font-mono text-slate-800">OneTimeWorkRequestBuilder&lt;DeleteFileWorker&gt;().setInitialDelay(60, TimeUnit.SECONDS)</code> to delete the PDF from Firebase Storage and local storage.
              </div>
            </li>
          </ul>
        </div>
      </div>

      {/* Printable Receipt Modal */}
      <ReceiptModal
        order={selectedReceipt}
        onClose={() => setSelectedReceipt(null)}
        shopId={shopId}
        printerName={connectedPrinter}
      />
    </div>
  );
};
