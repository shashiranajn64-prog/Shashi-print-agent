import React from 'react';
import { 
  Cpu, 
  Database, 
  DownloadCloud, 
  Printer, 
  Trash2, 
  ShieldCheck, 
  Radio, 
  FileCheck2, 
  Terminal, 
  Layers,
  ChevronRight,
  Sparkles
} from 'lucide-react';

export const ArchitectureGuide: React.FC = () => {
  return (
    <div className="space-y-8">
      {/* Overview Intro Banner */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-700">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 text-xs font-semibold">
            <Radio className="w-3.5 h-3.5 animate-pulse" />
            <span>Native Android Architecture Blueprint</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            How "Shashi Print Agent" Operates in the Background
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            The application is engineered to guarantee zero missed orders even if the shopkeeper turns off the screen or switches apps. It uses a high-priority Android Foreground Service linked to Firebase Firestore real-time snapshot listeners and hardware print drivers.
          </p>
        </div>
      </div>

      {/* The 5-Step Pipeline Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Step 1 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-pink-50 text-[#EC4899] flex items-center justify-center font-bold">
              01
            </div>
            <h3 className="font-bold text-base text-slate-900">Auth & ShopID Persistence</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Shopkeeper signs in using Firebase Auth Email & Password. The active <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px]">SHOP_ID</code> is persisted locally in <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px]">SharedPreferences</code> so subsequent phone reboots automatically resume the listener.
            </p>
          </div>
          <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 font-mono">
            MainActivity.kt · SharedPreferences
          </div>
        </div>

        {/* Step 2 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-pink-50 text-[#EC4899] flex items-center justify-center font-bold">
              02
            </div>
            <h3 className="font-bold text-base text-slate-900">Foreground Service & Sticky Notification</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px]">PrintForegroundService</code> runs with <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px]">START_STICKY</code> and a persistent notification <strong className="text-slate-800">"Shashi Print Agent - Active"</strong>, preventing Android Doze mode or aggressive battery killers from halting execution.
            </p>
          </div>
          <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 font-mono">
            PrintForegroundService.kt
          </div>
        </div>

        {/* Step 3 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-pink-50 text-[#EC4899] flex items-center justify-center font-bold">
              03
            </div>
            <h3 className="font-bold text-base text-slate-900">Firestore Real-Time Listener</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Attaches a snapshot listener to:
              <br />
              <code className="text-[#EC4899] font-mono text-[11px] block mt-1 bg-pink-50 p-1.5 rounded">
                shops/{'{shopId}'}/orders where status == "paid" & printed == false
              </code>
              Any new order arrives with sub-second latency via WebSocket push.
            </p>
          </div>
          <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 font-mono">
            addSnapshotListener
          </div>
        </div>

        {/* Step 4 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-pink-50 text-[#EC4899] flex items-center justify-center font-bold">
              04
            </div>
            <h3 className="font-bold text-base text-slate-900">DownloadManager to /Download/ShashiPrint/</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              When an order doc arrives, its <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px]">pdfUrl</code> is passed to Android <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px]">DownloadManager</code>. It saves the file to the dedicated folder <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px]">/Download/ShashiPrint/Order_*.pdf</code> and listens for download complete broadcast.
            </p>
          </div>
          <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 font-mono">
            DownloadManager.Request
          </div>
        </div>

        {/* Step 5 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-pink-50 text-[#EC4899] flex items-center justify-center font-bold">
              05
            </div>
            <h3 className="font-bold text-base text-slate-900">Android PrintManager Spooler</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Spools print using:
              <br />
              <code className="text-[#EC4899] font-mono text-[11px] block mt-1 bg-pink-50 p-1.5 rounded">
                printManager.print("Order_&#123;orderId&#125;", PdfPrintDocumentAdapter(), null)
              </code>
              Pipes the binary PDF stream directly to connected Bluetooth, USB, or Network Thermal POS printers.
            </p>
          </div>
          <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 font-mono">
            PdfPrintDocumentAdapter.kt
          </div>
        </div>

        {/* Step 6 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-pink-50 text-[#EC4899] flex items-center justify-center font-bold">
              06
            </div>
            <h3 className="font-bold text-base text-slate-900">Firestore Update & WorkManager Cleanup</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Upon successful print, updates Firestore: <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px]">printed=true, printedAt=FieldValue.serverTimestamp()</code>. Schedules <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px]">DeleteFileWorker</code> with a 60-second delay to delete the PDF from Firebase Storage and local storage.
            </p>
          </div>
          <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 font-mono">
            DeleteFileWorker.kt · WorkManager
          </div>
        </div>
      </div>

      {/* Permissions & Dependencies Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Permissions */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-4">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-[#EC4899]" />
            <h3 className="font-bold text-base text-slate-900">Declared Android Permissions</h3>
          </div>

          <div className="space-y-2 font-mono text-xs">
            {[
              { name: 'android.permission.INTERNET', purpose: 'Firebase Auth, Firestore snapshot listener & Storage downloads' },
              { name: 'android.permission.ACCESS_NETWORK_STATE', purpose: 'Network connection detection for automatic retry' },
              { name: 'android.permission.FOREGROUND_SERVICE', purpose: 'Persistent background execution without system throttling' },
              { name: 'android.permission.FOREGROUND_SERVICE_DATA_SYNC', purpose: 'Required Android 14+ foreground service type' },
              { name: 'android.permission.WRITE_EXTERNAL_STORAGE', purpose: 'DownloadManager file writing to /Download/ShashiPrint/' },
              { name: 'android.permission.POST_NOTIFICATIONS', purpose: 'Sticky notification on Android 13+ (API 33)' },
            ].map(perm => (
              <div key={perm.name} className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                <div className="text-pink-600 font-bold truncate">{perm.name}</div>
                <div className="text-slate-500 font-sans text-[11px]">{perm.purpose}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Firebase & Gradle Spec */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-4">
          <div className="flex items-center gap-2.5">
            <Layers className="w-5 h-5 text-[#EC4899]" />
            <h3 className="font-bold text-base text-slate-900">Firebase BoM 32.7.0 & Dependencies</h3>
          </div>

          <div className="space-y-2.5 text-xs text-slate-600">
            <p>
              The project is configured with official Firebase BoM 32.7.0 for harmonized versions without conflicts:
            </p>

            <div className="bg-slate-950 text-slate-200 p-3.5 rounded-xl font-mono text-xs space-y-1">
              <div className="text-slate-400">// Firebase BoM 32.7.0</div>
              <div>implementation(platform("com.google.firebase:firebase-bom:32.7.0"))</div>
              <div className="text-pink-400">implementation("com.google.firebase:firebase-auth-ktx")</div>
              <div className="text-pink-400">implementation("com.google.firebase:firebase-firestore-ktx")</div>
              <div className="text-pink-400">implementation("com.google.firebase:firebase-storage-ktx")</div>
              <div className="text-slate-400 mt-2">// Background WorkManager</div>
              <div>implementation("androidx.work:work-runtime-ktx:2.9.0")</div>
            </div>

            <div className="p-3 bg-pink-50/70 rounded-xl border border-pink-100 text-[11px] text-pink-900 leading-relaxed">
              <strong>Thermal POS Hardware Note:</strong> Compatible with all standard 58mm & 80mm ESC/POS printers via Bluetooth, USB OTG, or Network LAN, using standard Android Print Spooler plugins (like RawBT, HP Print Service, or ESC POS Print Service).
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
