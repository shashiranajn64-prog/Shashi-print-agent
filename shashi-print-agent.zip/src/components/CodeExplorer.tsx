import React, { useState } from 'react';
import { ANDROID_FILES, ProjectFile } from '../data/androidProjectFiles';
import { 
  FileCode, 
  Download, 
  Copy, 
  Check, 
  Search, 
  Folder, 
  FileText, 
  Layers, 
  FolderTree, 
  Archive, 
  ExternalLink,
  Code2
} from 'lucide-react';
import JSZip from 'jszip';

export const CodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<ProjectFile>(ANDROID_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isZipping, setIsZipping] = useState(false);

  // Filter files by search term
  const filteredFiles = ANDROID_FILES.filter(
    f => f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
         f.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
         f.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Group files by category
  const categories = Array.from(new Set(ANDROID_FILES.map(f => f.category)));

  // Copy code handler
  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Download single file handler
  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = selectedFile.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Download entire Android Studio project as .ZIP
  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      // Populate files into zip with relative directory structure
      ANDROID_FILES.forEach(file => {
        zip.file(file.path, file.content);
      });

      // Add a standard .gitignore for Android Studio
      zip.file(
        '.gitignore',
        `*.iml
.gradle
/local.properties
/.idea/caches
/.idea/libraries
/.idea/modules.xml
/.idea/workspace.xml
/.idea/navEditor.xml
/.idea/assetWizardSettings.xml
.DS_Store
/build
/captures
.externalNativeBuild
.cxx
local.properties
`
      );

      // Generate zip file
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'ShashiPrintAgent_Android_Project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to create zip', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-[780px]">
      {/* Top Bar */}
      <div className="px-6 py-4 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#EC4899] flex items-center justify-center text-white">
            <Code2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-white flex items-center gap-2">
              <span>Android Studio Kotlin Project Files</span>
              <span className="text-[10px] bg-slate-800 text-pink-300 font-mono px-2 py-0.5 rounded-full border border-slate-700">
                12 Files Ready
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Native Kotlin 1.9 · Firebase BoM 32.7.0 · Material 3 · DownloadManager & PrintManager
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="py-2 px-3.5 rounded-xl bg-[#EC4899] hover:bg-[#db2777] text-white text-xs font-semibold shadow-md shadow-pink-900/30 flex items-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
          >
            <Archive className="w-4 h-4" />
            <span>{isZipping ? 'Packaging ZIP...' : 'Download Project (.zip)'}</span>
          </button>
        </div>
      </div>

      {/* Main Body: Sidebar Tree + Code Area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar - File Explorer */}
        <div className="w-80 border-r border-slate-200 bg-slate-50/70 flex flex-col shrink-0">
          {/* Search Bar */}
          <div className="p-3 border-b border-slate-200">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search files..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-[#EC4899]"
              />
            </div>
          </div>

          {/* Grouped File Tree */}
          <div className="flex-1 overflow-y-auto p-2 space-y-3">
            {categories.map(category => {
              const filesInCategory = filteredFiles.filter(f => f.category === category);
              if (filesInCategory.length === 0) return null;

              return (
                <div key={category} className="space-y-1">
                  <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <Folder className="w-3 h-3 text-slate-400" />
                    <span>{category}</span>
                  </div>

                  <div className="space-y-0.5">
                    {filesInCategory.map(file => {
                      const isSelected = selectedFile.path === file.path;
                      return (
                        <button
                          key={file.path}
                          onClick={() => setSelectedFile(file)}
                          className={`w-full text-left px-2.5 py-2 rounded-lg text-xs flex items-center gap-2.5 transition-all ${
                            isSelected
                              ? 'bg-white text-[#EC4899] font-bold shadow-sm border border-pink-100'
                              : 'text-slate-700 hover:bg-slate-100/80 font-medium'
                          }`}
                        >
                          <FileCode
                            className={`w-3.5 h-3.5 shrink-0 ${
                              isSelected ? 'text-[#EC4899]' : 'text-slate-400'
                            }`}
                          />
                          <div className="flex-1 truncate">
                            <span className="truncate block">{file.name}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Area - Code Viewer & Details */}
        <div className="flex-1 flex flex-col overflow-hidden bg-slate-950 text-slate-100">
          {/* File Header Details */}
          <div className="px-5 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div className="min-w-0 pr-4">
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-xs text-pink-300">
                  {selectedFile.path}
                </span>
                <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded uppercase font-mono">
                  {selectedFile.language}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate mt-0.5">
                {selectedFile.description}
              </p>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleCopy}
                className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-medium flex items-center gap-1.5 transition-colors border border-slate-700"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy Code'}</span>
              </button>

              <button
                onClick={handleDownloadFile}
                className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-medium flex items-center gap-1.5 transition-colors border border-slate-700"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save File</span>
              </button>
            </div>
          </div>

          {/* Syntax Highlighted Code Viewer */}
          <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed selection:bg-pink-900 selection:text-pink-100">
            <pre className="text-slate-300 whitespace-pre">
              <code>
                {selectedFile.content.split('\n').map((line, idx) => (
                  <div key={idx} className="table-row hover:bg-slate-900/60 transition-colors">
                    <span className="table-cell select-none text-right pr-4 text-slate-600 text-[11px] w-10">
                      {idx + 1}
                    </span>
                    <span className="table-cell">{line}</span>
                  </div>
                ))}
              </code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
