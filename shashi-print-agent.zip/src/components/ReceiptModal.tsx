import React from 'react';
import { X, Printer, CheckCircle, Calendar, Hash, User, FileText } from 'lucide-react';

export interface OrderData {
  id: string;
  customerName: string;
  totalAmount: number;
  itemsSummary: string;
  status: 'paid' | 'pending';
  printed: boolean;
  printedAt: string;
  pdfUrl?: string;
  items?: { name: string; qty: number; price: number }[];
}

interface ReceiptModalProps {
  order: OrderData | null;
  onClose: () => void;
  shopId: string;
  printerName: string;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  order,
  onClose,
  shopId,
  printerName,
}) => {
  if (!order) return null;

  const items = order.items || [
    { name: 'Photo Print Glossy 4x6', qty: 2, price: 60 },
    { name: 'Document B&W A4 Print', qty: 15, price: 75 },
    { name: 'Spiral Binding & Lamination', qty: 1, price: 45 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200">
        {/* Header bar */}
        <div className="bg-[#EC4899] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5" />
            <h3 className="font-bold text-base">Thermal Print Preview</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Paper receipt container */}
        <div className="p-6 bg-[#FDFBF7] font-mono text-xs text-slate-800 space-y-3">
          <div className="text-center space-y-1 border-b border-dashed border-slate-300 pb-3">
            <h4 className="font-bold text-base uppercase tracking-wider text-slate-900">
              SHASHI PRINT SHOP
            </h4>
            <p className="text-[11px] text-slate-500">Shop ID: {shopId}</p>
            <p className="text-[10px] text-slate-400">Android PrintManager Spooler</p>
          </div>

          <div className="space-y-1 py-1 border-b border-dashed border-slate-300 pb-3 text-[11px]">
            <div className="flex justify-between">
              <span className="text-slate-500">Order ID:</span>
              <span className="font-bold text-slate-800">#{order.id.slice(-6).toUpperCase()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Customer:</span>
              <span className="font-semibold text-slate-800">{order.customerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Timestamp:</span>
              <span>{order.printedAt || 'Just now'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Printer:</span>
              <span className="text-slate-700">{printerName}</span>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="space-y-1.5 py-1 border-b border-dashed border-slate-300 pb-3">
            <div className="flex justify-between font-bold text-slate-700 text-[10px] uppercase">
              <span>Item</span>
              <span>Qty x Rate</span>
              <span>Total</span>
            </div>
            {items.map((item, idx) => (
              <div key={idx} className="flex justify-between text-[11px]">
                <span className="truncate max-w-[140px]">{item.name}</span>
                <span className="text-slate-500">
                  {item.qty} × ₹{Math.round(item.price / item.qty)}
                </span>
                <span className="font-semibold">₹{item.price}</span>
              </div>
            ))}
          </div>

          {/* Grand total */}
          <div className="pt-1 space-y-1">
            <div className="flex justify-between font-bold text-sm text-slate-900">
              <span>TOTAL PAID</span>
              <span className="text-[#EC4899]">₹{order.totalAmount}</span>
            </div>
            <div className="flex items-center justify-center gap-1.5 text-[10px] text-emerald-600 font-sans font-semibold pt-2">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Printed & Synced to Firestore</span>
            </div>
            <p className="text-center text-[9px] text-slate-400 font-mono pt-1">
              *** Thank You · Powered by Shashi Print Agent ***
            </p>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="w-full py-2 px-4 rounded-xl text-xs font-semibold bg-[#EC4899] text-white hover:bg-[#db2777] transition-colors"
          >
            Close Receipt
          </button>
        </div>
      </div>
    </div>
  );
};
