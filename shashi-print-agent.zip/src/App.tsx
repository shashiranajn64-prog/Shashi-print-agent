import React, { useState } from 'react';
import { PhoneSimulator } from './components/PhoneSimulator';
import { CodeExplorer } from './components/CodeExplorer';
import { ArchitectureGuide } from './components/ArchitectureGuide';
import { ANDROID_FILES } from './data/androidProjectFiles';
import { 
  Smartphone, 
  Code2, 
  Layers, 
  Archive, 
  Printer, 
  CheckCircle2, 
  ExternalLink,
  Github,
  Zap,
  Sparkles
} from 'lucide-react';
import JSZip from 'jszip';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'code' | 'architecture'>('simulator');
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  // Download all files as a clean ready-to-run ZIP archive
  const handleDownloadAllZip = async () => {
    try {
      setIsDownloadingZip(true);
      const zip = new JSZip();

      ANDROID_FILES.forEach(file => {
        zip.file(file.path, file.content);
      });

      zip.file(
        '.gitignore',
        `*.iml\n.gradle\n/local.properties\n/.idea\n.DS_Store\n/build\n`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'ShashiPrintAgent_Android_Kotlin_Project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* ================= TOP NAVIGATION (Strict 3-zone contract) ================= */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          {/* Zone 1: Brand Title (single text element wordmark in display face) */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#EC4899] text-white flex items-center justify-center shadow-sm">
              <Printer className="w-4 h-4" />
            </div>
            <a href="#" className="text-base font-extrabold tracking-tight text-slate-900">
              Shashi Print Agent
            </a>
          </div>

          {/* Zone 2: Navigation Links (interactive tab segmented switch) */}
          <nav className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === 'simulator'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 text-[#EC4899]" />
              <span className="hidden sm:inline">Interactive</span> App
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === 'code'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Code2 className="w-3.5 h-3.5 text-[#EC4899]" />
              <span className="hidden sm:inline">Project</span> Code
            </button>

            <button
              onClick={() => setActiveTab('architecture')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === 'architecture'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-[#EC4899]" />
              <span>Architecture</span>
            </button>
          </nav>

          {/* Zone 3: Primary Action CTA */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadAllZip}
              disabled={isDownloadingZip}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-[#EC4899] hover:bg-[#db2777] rounded-xl shadow-sm transition-all flex items-center gap-1.5 active:scale-[0.98] disabled:opacity-50"
            >
              <Archive className="w-3.5 h-3.5" />
              <span>{isDownloadingZip ? 'Packaging...' : 'Download .ZIP'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* ================= MAIN CONTENT ================= */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-6 sm:py-8">
        {/* Context metadata kicker (zero-pill discipline) */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="font-semibold text-slate-700">Android Kotlin Project</span>
            <span aria-hidden="true">·</span>
            <span>Firebase BoM 32.7.0</span>
            <span aria-hidden="true">·</span>
            <span>Jetpack Compose Material 3</span>
            <span aria-hidden="true">·</span>
            <span className="text-[#EC4899] font-medium">Pink #EC4899</span>
          </div>

          <div className="text-xs text-slate-500 flex items-center gap-3">
            <span>Package: <code className="font-mono text-slate-700">com.shashiprint.agent</code></span>
          </div>
        </div>

        {/* Tab 1: Interactive Phone Simulator */}
        {activeTab === 'simulator' && (
          <div className="space-y-6">
            <PhoneSimulator />
          </div>
        )}

        {/* Tab 2: Project Source Codebase */}
        {activeTab === 'code' && (
          <div className="space-y-6">
            <CodeExplorer />
          </div>
        )}

        {/* Tab 3: Architecture Blueprint & Guidelines */}
        {activeTab === 'architecture' && (
          <div className="space-y-6">
            <ArchitectureGuide />
          </div>
        )}
      </main>

      {/* ================= CLEAN FOOTER ================= */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <p>© Shashi Print Agent · Production-grade Android Native POS & Order Printing Solution</p>
          <div className="flex items-center gap-4">
            <span>Firestore Snapshot Listener</span>
            <span>·</span>
            <span>Android PrintManager</span>
            <span>·</span>
            <span>WorkManager 60s Purge</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
