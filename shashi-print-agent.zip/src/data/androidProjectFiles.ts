export interface ProjectFile {
  path: string;
  name: string;
  language: 'kotlin' | 'xml' | 'groovy' | 'json' | 'markdown';
  category: 'Kotlin Code' | 'Manifest' | 'Gradle Build' | 'Resources & Config' | 'Documentation';
  description: string;
  content: string;
}

export const ANDROID_FILES: ProjectFile[] = [
  {
    path: 'app/src/main/java/com/shashiprint/agent/MainActivity.kt',
    name: 'MainActivity.kt',
    language: 'kotlin',
    category: 'Kotlin Code',
    description: 'Main UI entry point with Material 3, Shopkeeper Auth, Printer config, and Service controllers',
    content: `package com.shashiprint.agent

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.shashiprint.agent.ui.theme.ShashiPrintTheme
import java.text.SimpleDateFormat
import java.util.*

// Data class representing an Order record from Firestore
data class OrderItem(
    val id: String = "",
    val customerName: String = "",
    val totalAmount: Double = 0.0,
    val itemsSummary: String = "",
    val status: String = "paid",
    val printed: Boolean = false,
    val printedAt: Date? = null,
    val pdfUrl: String = ""
)

class MainActivity : ComponentActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var prefs: SharedPreferences

    companion object {
        const val PREF_NAME = "shashi_print_prefs"
        const val KEY_SHOP_ID = "saved_shop_id"
        const val KEY_AUTO_PRINT = "auto_print_enabled"
        const val KEY_PRINTER_NAME = "connected_printer_name"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

        setContent {
            ShashiPrintTheme {
                MainAppNavHost(
                    auth = auth,
                    prefs = prefs,
                    onStartService = { startPrintService() },
                    onStopService = { stopPrintService() }
                )
            }
        }
    }

    private fun startPrintService() {
        val shopId = prefs.getString(KEY_SHOP_ID, null)
        if (shopId.isNullOrEmpty()) {
            Toast.makeText(this, "Please log in and configure Shop ID first", Toast.LENGTH_SHORT).show()
            return
        }

        val serviceIntent = Intent(this, PrintForegroundService::class.java).apply {
            action = PrintForegroundService.ACTION_START
            putExtra(PrintForegroundService.EXTRA_SHOP_ID, shopId)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun stopPrintService() {
        val serviceIntent = Intent(this, PrintForegroundService::class.java).apply {
            action = PrintForegroundService.ACTION_STOP
        }
        startService(serviceIntent)
    }
}

@Composable
fun MainAppNavHost(
    auth: FirebaseAuth,
    prefs: SharedPreferences,
    onStartService: () -> Unit,
    onStopService: () -> Unit
) {
    val context = LocalContext.current
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var savedShopId by remember { 
        mutableStateOf(prefs.getString(MainActivity.KEY_SHOP_ID, "") ?: "") 
    }

    // Permission request launcher for POST_NOTIFICATIONS (Android 13+) and Storage
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val notifGranted = permissions[Manifest.permission.POST_NOTIFICATIONS] ?: true
        if (!notifGranted) {
            Toast.makeText(context, "Notifications are required for background print listener", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        val neededPermissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) 
                != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) 
                != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }
        if (neededPermissions.isNotEmpty()) {
            permissionLauncher.launch(neededPermissions.toTypedArray())
        }
    }

    if (currentUser == null || savedShopId.isEmpty()) {
        LoginScreen(
            auth = auth,
            initialShopId = savedShopId,
            onLoginSuccess = { shopId ->
                prefs.edit().putString(MainActivity.KEY_SHOP_ID, shopId).apply()
                savedShopId = shopId
                currentUser = auth.currentUser
                onStartService()
            }
        )
    } else {
        MainDashboardScreen(
            shopId = savedShopId,
            prefs = prefs,
            onLogout = {
                onStopService()
                auth.signOut()
                currentUser = null
            },
            onRestartService = onStartService,
            onStopService = onStopService
        )
    }
}

/**
 * 1. Login Screen: Shopkeeper login with Firebase Auth (Email/Pass).
 * Saves ShopID locally into SharedPreferences.
 */
@Composable
fun LoginScreen(
    auth: FirebaseAuth,
    initialShopId: String,
    onLoginSuccess: (String) -> Unit
) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("shopkeeper@shashiprint.com") }
    var password by remember { mutableStateOf("print123456") }
    var shopId by remember { mutableStateOf(if (initialShopId.isNotEmpty()) initialShopId else "SHOP_PATNA_01") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Brand
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEC4899)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = "Print Agent",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Shashi Print Agent",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B)
                    )

                    Text(
                        text = "Shopkeeper POS Auto-Print Terminal",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Shop ID Field (Saved locally)
                    OutlinedTextField(
                        value = shopId,
                        onValueChange = { shopId = it.uppercase().trim() },
                        label = { Text("Shop ID (e.g. SHOP_01)") },
                        leadingIcon = { Icon(Icons.Default.Store, contentDescription = null, tint = Color(0xFFEC4899)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Email Field
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it.trim() },
                        label = { Text("Shopkeeper Email") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = Color(0xFFEC4899)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Password Field
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFEC4899)) },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    errorMessage?.let { error ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = error,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Submit Button
                    Button(
                        onClick = {
                            if (shopId.isEmpty()) {
                                errorMessage = "Please enter a valid Shop ID"
                                return@Button
                            }
                            if (email.isEmpty() || password.isEmpty()) {
                                errorMessage = "Please enter your Email and Password"
                                return@Button
                            }

                            isLoading = true
                            errorMessage = null

                            auth.signInWithEmailAndPassword(email, password)
                                .addOnSuccessListener {
                                    isLoading = false
                                    Toast.makeText(context, "Login Successful! Connecting agent...", Toast.LENGTH_SHORT).show()
                                    onLoginSuccess(shopId)
                                }
                                .addOnFailureListener { e ->
                                    isLoading = false
                                    errorMessage = e.localizedMessage ?: "Authentication failed. Check credentials."
                                }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEC4899)),
                        enabled = !isLoading
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "Sign In & Launch Agent",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 2. Main Screen:
 * - "Agent Active - Waiting for Orders..." with Green Dot
 * - Show connected printer name
 * - Toggle: Auto-Print ON/OFF
 * - List of last 5 printed orders
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardScreen(
    shopId: String,
    prefs: SharedPreferences,
    onLogout: () -> Unit,
    onRestartService: () -> Unit,
    onStopService: () -> Unit
) {
    val context = LocalContext.current
    var autoPrintEnabled by remember {
        mutableStateOf(prefs.getBoolean(MainActivity.KEY_AUTO_PRINT, true))
    }
    var connectedPrinter by remember {
        mutableStateOf(prefs.getString(MainActivity.KEY_PRINTER_NAME, "POS-80 Thermal USB/BT") ?: "POS-80 Thermal USB/BT")
    }

    var lastOrders by remember { mutableStateOf<List<OrderItem>>(emptyList()) }
    var isListening by remember { mutableStateOf(true) }

    // Real-time listener for the last 5 printed orders
    DisposableEffect(shopId) {
        val firestore = FirebaseFirestore.getInstance()
        val query = firestore.collection("shops")
            .document(shopId)
            .collection("orders")
            .whereEqualTo("printed", true)
            .orderBy("printedAt", Query.Direction.DESCENDING)
            .limit(5)

        val registration = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val orders = snapshot.documents.map { doc ->
                    OrderItem(
                        id = doc.id,
                        customerName = doc.getString("customerName") ?: "Customer",
                        totalAmount = doc.getDouble("totalAmount") ?: 0.0,
                        itemsSummary = doc.getString("itemsSummary") ?: "Order items",
                        status = doc.getString("status") ?: "paid",
                        printed = doc.getBoolean("printed") ?: true,
                        printedAt = doc.getDate("printedAt"),
                        pdfUrl = doc.getString("pdfUrl") ?: ""
                    )
                }
                lastOrders = orders
            }
        }

        onDispose {
            registration.remove()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Shashi Print Agent",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Shop ID: $shopId",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFEC4899)
                ),
                actions = {
                    IconButton(onClick = onLogout) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = "Logout",
                            tint = Color.White
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8FAFC))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Agent Status with Pulsing Green Dot
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Green Dot Indicator
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(if (autoPrintEnabled) Color(0xFF10B981) else Color(0xFFF59E0B))
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (autoPrintEnabled) 
                                    "Agent Active - Waiting for Orders..." 
                                else 
                                    "Agent Paused - Auto-Print Off",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Real-time Firestore listener synced to shop: $shopId",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }
            }

            // Section 2: Connected Printer Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFFDF2F8)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Print,
                                    contentDescription = "Printer",
                                    tint = Color(0xFFEC4899)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Connected Printer",
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B)
                                )
                                Text(
                                    text = connectedPrinter,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 16.sp,
                                    color = Color(0xFF1E293B)
                                )
                            }

                            TextButton(
                                onClick = {
                                    // Switch printer mock or open system print spooler
                                    val nextPrinter = if (connectedPrinter.contains("POS-80")) 
                                        "HP LaserJet Pro M404dn (Network)" 
                                    else 
                                        "POS-80 Thermal USB/BT"
                                    connectedPrinter = nextPrinter
                                    prefs.edit().putString(MainActivity.KEY_PRINTER_NAME, nextPrinter).apply()
                                    Toast.makeText(context, "Printer changed to $nextPrinter", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Text("Change", color = Color(0xFFEC4899))
                            }
                        }
                    }
                }
            }

            // Section 3: Toggle Auto-Print ON/OFF
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Auto-Print Mode",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp,
                                color = Color(0xFF1E293B)
                            )
                            Text(
                                text = if (autoPrintEnabled) "Orders print immediately upon payment" else "Printing is paused",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }

                        Switch(
                            checked = autoPrintEnabled,
                            onCheckedChange = { isChecked ->
                                autoPrintEnabled = isChecked
                                prefs.edit().putBoolean(MainActivity.KEY_AUTO_PRINT, isChecked).apply()
                                if (isChecked) {
                                    onRestartService()
                                    Toast.makeText(context, "Auto-Print Activated", Toast.LENGTH_SHORT).show()
                                } else {
                                    onStopService()
                                    Toast.makeText(context, "Auto-Print Paused", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFFEC4899),
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = Color(0xFFCBD5E1)
                            )
                        )
                    }
                }
            }

            // Section 4: Header for Last 5 Printed Orders
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Last 5 Printed Orders",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = "Sync: Real-time",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }

            // List of Orders
            if (lastOrders.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Outlined.ReceiptLong,
                                    contentDescription = null,
                                    tint = Color(0xFFCBD5E1),
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No printed orders yet",
                                    fontSize = 14.sp,
                                    color = Color(0xFF64748B)
                                )
                                Text(
                                    text = "New paid orders will appear here automatically",
                                    fontSize = 12.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }
            } else {
                items(lastOrders) { order ->
                    OrderHistoryCard(order = order)
                }
            }
        }
    }
}

@Composable
fun OrderHistoryCard(order: OrderItem) {
    val dateFormat = remember { SimpleDateFormat("hh:mm a, dd MMM", Locale.getDefault()) }
    val formattedTime = order.printedAt?.let { dateFormat.format(it) } ?: "Just now"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFECFDF5)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Printed",
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Order #\${order.id.takeLast(6).uppercase()}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = "₹\${order.totalAmount}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFFEC4899)
                    )
                }

                Text(
                    text = "\${order.customerName} · \${order.itemsSummary}",
                    fontSize = 12.sp,
                    color = Color(0xFF475569)
                )

                Text(
                    text = "Printed at \${formattedTime}",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )
            }
        }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/shashiprint/agent/PrintForegroundService.kt',
    name: 'PrintForegroundService.kt',
    language: 'kotlin',
    category: 'Kotlin Code',
    description: 'Foreground Service running sticky notification, Firestore real-time listener, DownloadManager, and Android PrintManager',
    content: `package com.shashiprint.agent

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.io.File
import java.util.concurrent.TimeUnit

class PrintForegroundService : Service() {

    companion object {
        private const val TAG = "ShashiPrintService"
        const val CHANNEL_ID = "shashi_print_foreground_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.shashiprint.agent.START"
        const val ACTION_STOP = "com.shashiprint.agent.STOP"
        const val EXTRA_SHOP_ID = "extra_shop_id"
    }

    private var shopId: String? = null
    private var firestoreListener: ListenerRegistration? = null
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private lateinit var downloadManager: DownloadManager

    // Map to track active downloads: downloadId -> Pair(orderId, localPdfPath)
    private val pendingPrintJobs = mutableMapOf<Long, Pair<String, String>>()

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == DownloadManager.ACTION_DOWNLOAD_COMPLETE) {
                val downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                if (downloadId != -1L && pendingPrintJobs.containsKey(downloadId)) {
                    val job = pendingPrintJobs.remove(downloadId)
                    job?.let { (orderId, localPdfPath) ->
                        handleDownloadedPdf(orderId, localPdfPath)
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        createNotificationChannel()

        // Register broadcast receiver for download completion
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(downloadReceiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val newShopId = intent.getStringExtra(EXTRA_SHOP_ID)
                if (!newShopId.isNullOrEmpty()) {
                    shopId = newShopId
                    startForeground(NOTIFICATION_ID, buildForegroundNotification("Active - Listening to shop: $shopId"))
                    startFirestoreOrdersListener(newShopId)
                }
            }
            ACTION_STOP -> {
                stopForegroundListener()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    /**
     * 3. Background Service:
     * Firestore real-time listener:
     * FirebaseFirestore.getInstance().collection("shops").document(SHOP_ID)
     *   .collection("orders").whereEqualTo("status","paid").whereEqualTo("printed",false)
     *   .addSnapshotListener
     */
    private fun startFirestoreOrdersListener(currentShopId: String) {
        stopForegroundListener()

        Log.d(TAG, "Starting Firestore listener for shop: $currentShopId")

        firestoreListener = firestore.collection("shops")
            .document(currentShopId)
            .collection("orders")
            .whereEqualTo("status", "paid")
            .whereEqualTo("printed", false)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.e(TAG, "Firestore listen error: \${error.message}", error)
                    updateNotification("Error syncing orders: \${error.localizedMessage}")
                    return@addSnapshotListener
                }

                if (snapshots != null && !snapshots.isEmpty) {
                    for (doc in snapshots.documents) {
                        val orderId = doc.id
                        val pdfUrl = doc.getString("pdfUrl") ?: ""
                        Log.d(TAG, "New unprinted paid order received: $orderId, pdfUrl: $pdfUrl")

                        if (pdfUrl.isNotEmpty()) {
                            // a) Download PDF URL from Firebase Storage using DownloadManager
                            downloadOrderPdf(orderId, pdfUrl)
                        } else {
                            Log.w(TAG, "Order $orderId has no PDF url attached")
                        }
                    }
                }
            }
    }

    /**
     * a) Download PDF URL from Firebase Storage using DownloadManager to /Download/ShashiPrint/
     */
    private fun downloadOrderPdf(orderId: String, pdfUrl: String) {
        try {
            val fileName = "Order_\${orderId}.pdf"
            val targetDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "ShashiPrint"
            )
            if (!targetDir.exists()) {
                targetDir.mkdirs()
            }

            val destinationFile = File(targetDir, fileName)
            if (destinationFile.exists()) {
                destinationFile.delete()
            }

            val request = DownloadManager.Request(Uri.parse(pdfUrl))
                .setTitle("Downloading Invoice #$orderId")
                .setDescription("Shashi Print Agent auto-download")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                .setDestinationUri(Uri.fromFile(destinationFile))
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)

            val downloadId = downloadManager.enqueue(request)
            pendingPrintJobs[downloadId] = Pair(orderId, destinationFile.absolutePath)
            Log.d(TAG, "Enqueued download $downloadId for order: $orderId to \${destinationFile.absolutePath}")

        } catch (e: Exception) {
            Log.e(TAG, "DownloadManager enqueue failed: \${e.message}", e)
        }
    }

    /**
     * b) Print it automatically using Android PrintManager:
     * Use PrintManager + PrintDocumentAdapter for PDF.
     * Code:
     *   val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
     *   printManager.print("Order_\${orderId}", PrintDocumentAdapter(), null)
     */
    private fun handleDownloadedPdf(orderId: String, localPdfPath: String) {
        val pdfFile = File(localPdfPath)
        if (!pdfFile.exists() || pdfFile.length() == 0L) {
            Log.e(TAG, "Downloaded PDF does not exist or is empty: $localPdfPath")
            return
        }

        try {
            val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
            val jobName = "Order_\${orderId}"

            // Print using robust PdfPrintDocumentAdapter
            val printAdapter = PdfPrintDocumentAdapter(this, pdfFile) { isSuccess ->
                if (isSuccess) {
                    Log.d(TAG, "Print job completed successfully for order: $orderId")
                    onPrintCompletedSuccessfully(orderId, localPdfPath)
                } else {
                    Log.w(TAG, "Print job cancelled or failed for order: $orderId")
                }
            }

            val printAttributes = PrintAttributes.Builder()
                .setContentType(PrintAttributes.ContentType.CONTENT_TYPE_DOCUMENT)
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .build()

            printManager.print(jobName, printAdapter, printAttributes)
            Log.d(TAG, "Dispatched print job to PrintManager: $jobName")

        } catch (e: Exception) {
            Log.e(TAG, "Failed to print order $orderId: \${e.message}", e)
        }
    }

    /**
     * c) After print success, update Firestore: printed=true, printedAt=now.
     * And delete file from Storage after 60 sec using WorkManager.
     */
    private fun onPrintCompletedSuccessfully(orderId: String, localPdfPath: String) {
        val currentShopId = shopId ?: return

        // Update Firestore: printed = true, printedAt = server timestamp
        firestore.collection("shops")
            .document(currentShopId)
            .collection("orders")
            .document(orderId)
            .update(
                mapOf(
                    "printed" to true,
                    "printedAt" to FieldValue.serverTimestamp()
                )
            )
            .addOnSuccessListener {
                Log.d(TAG, "Firestore updated successfully for order: $orderId (printed=true)")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Failed to update order $orderId status: \${e.message}", e)
            }

        // Schedule WorkManager worker to delete the file after 60 seconds
        val workData = Data.Builder()
            .putString(DeleteFileWorker.KEY_ORDER_ID, orderId)
            .putString(DeleteFileWorker.KEY_SHOP_ID, currentShopId)
            .putString(DeleteFileWorker.KEY_LOCAL_PATH, localPdfPath)
            .build()

        val cleanupRequest = OneTimeWorkRequestBuilder<DeleteFileWorker>()
            .setInitialDelay(60, TimeUnit.SECONDS)
            .setInputData(workData)
            .build()

        WorkManager.getInstance(applicationContext).enqueue(cleanupRequest)
        Log.d(TAG, "WorkManager scheduled cleanup for order $orderId in 60 seconds")
    }

    private fun stopForegroundListener() {
        firestoreListener?.remove()
        firestoreListener = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Shashi Print Agent Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground channel for background orders listener"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(contentText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Shashi Print Agent - Active")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setColor(0xFFEC4899.toInt())
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(newText: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildForegroundNotification(newText))
    }

    override fun onDestroy() {
        super.onDestroy()
        stopForegroundListener()
        try {
            unregisterReceiver(downloadReceiver)
        } catch (_: Exception) {}
        Log.d(TAG, "PrintForegroundService destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
`,
  },
  {
    path: 'app/src/main/java/com/shashiprint/agent/PdfPrintDocumentAdapter.kt',
    name: 'PdfPrintDocumentAdapter.kt',
    language: 'kotlin',
    category: 'Kotlin Code',
    description: 'Custom PrintDocumentAdapter implementation piping PDF stream directly into Android PrintManager spooler',
    content: `package com.shashiprint.agent

import android.content.Context
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.util.Log
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

/**
 * Standard Android PrintDocumentAdapter wrapper for printing local PDF files.
 * Streams the PDF directly to the system print spooler.
 */
class PdfPrintDocumentAdapter(
    private val context: Context,
    private val pdfFile: File,
    private val onFinishCallback: (Boolean) -> Unit = {}
) : PrintDocumentAdapter() {

    companion object {
        private const val TAG = "PdfPrintAdapter"
    }

    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes?,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback?,
        extras: Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback?.onLayoutCancelled()
            return
        }

        // Prepare document info for PDF
        val info = PrintDocumentInfo.Builder(pdfFile.name)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
            .build()

        callback?.onLayoutFinished(info, newAttributes != oldAttributes)
    }

    override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor?,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback?
    ) {
        var input: FileInputStream? = null
        var output: FileOutputStream? = null

        try {
            if (cancellationSignal?.isCanceled == true) {
                callback?.onWriteCancelled()
                onFinishCallback(false)
                return
            }

            input = FileInputStream(pdfFile)
            output = FileOutputStream(destination?.fileDescriptor)

            val buffer = ByteArray(4096)
            var bytesRead: Int

            while (input.read(buffer).also { bytesRead = it } >= 0) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onWriteCancelled()
                    onFinishCallback(false)
                    return
                }
                output.write(buffer, 0, bytesRead)
            }

            callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            onFinishCallback(true)

        } catch (e: Exception) {
            Log.e(TAG, "Error writing PDF to print spooler: \${e.message}", e)
            callback?.onWriteFailed(e.localizedMessage)
            onFinishCallback(false)
        } finally {
            try {
                input?.close()
                output?.close()
            } catch (ioe: IOException) {
                Log.e(TAG, "Error closing streams: \${ioe.message}", ioe)
            }
        }
    }

    override fun onFinish() {
        super.onFinish()
        Log.d(TAG, "Print adapter execution finished for: \${pdfFile.name}")
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/shashiprint/agent/DeleteFileWorker.kt',
    name: 'DeleteFileWorker.kt',
    language: 'kotlin',
    category: 'Kotlin Code',
    description: 'WorkManager Worker that runs 60 seconds after successful print to delete temporary PDF from storage and local cache',
    content: `package com.shashiprint.agent

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Scheduled via WorkManager with a 60-second delay after print completion:
 * "And delete file from Storage after 60 sec using WorkManager."
 */
class DeleteFileWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val TAG = "DeleteFileWorker"
        const val KEY_ORDER_ID = "order_id"
        const val KEY_SHOP_ID = "shop_id"
        const val KEY_LOCAL_PATH = "local_path"
    }

    override fun suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val orderId = inputData.getString(KEY_ORDER_ID) ?: return@withContext Result.failure()
        val shopId = inputData.getString(KEY_SHOP_ID) ?: return@withContext Result.failure()
        val localPath = inputData.getString(KEY_LOCAL_PATH)

        Log.d(TAG, "Executing 60-second delayed cleanup for Order: $orderId (Shop: $shopId)")

        // 1. Delete local file from /Download/ShashiPrint/
        if (!localPath.isNullOrEmpty()) {
            try {
                val file = File(localPath)
                if (file.exists()) {
                    val deleted = file.delete()
                    Log.d(TAG, "Local file deleted ($localPath): $deleted")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete local PDF: \${e.message}", e)
            }
        }

        // 2. Delete file from Firebase Storage: shops/{shopId}/orders/{orderId}.pdf
        try {
            val storage = FirebaseStorage.getInstance()
            val storageRef = storage.reference.child("shops/$shopId/orders/$orderId.pdf")
            storageRef.delete().await()
            Log.d(TAG, "Firebase Storage PDF deleted for order: $orderId")
        } catch (e: Exception) {
            // Even if Firebase storage file was already removed or had custom name, log gracefully
            Log.w(TAG, "Firebase Storage file cleanup notice: \${e.message}")
        }

        Result.success()
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/shashiprint/agent/ShashiPrintApp.kt',
    name: 'ShashiPrintApp.kt',
    language: 'kotlin',
    category: 'Kotlin Code',
    description: 'Application class initializing Firebase, notification channels, and global configuration',
    content: `package com.shashiprint.agent

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.google.firebase.FirebaseApp

class ShashiPrintApp : Application() {

    override fun onCreate() {
        super.onCreate()
        
        // Initialize Firebase SDK
        FirebaseApp.initializeApp(this)

        // Create foreground notification channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                PrintForegroundService.CHANNEL_ID,
                "Shashi Print Agent Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps print agent active to receive real-time paid orders"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/shashiprint/agent/ui/theme/Theme.kt',
    name: 'Theme.kt',
    language: 'kotlin',
    category: 'Kotlin Code',
    description: 'Material 3 Color Scheme & Theme specification with Pink #EC4899 and White styling',
    content: `package com.shashiprint.agent.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Palette with requested Pink #EC4899, White, and slate accents
val PinkPrimary = Color(0xFFEC4899)
val PinkLight = Color(0xFFFDF2F8)
val PinkDark = Color(0xFFBE185D)
val White = Color(0xFFFFFFFF)
val SlateBackground = Color(0xFFF8FAFC)
val SlateTextPrimary = Color(0xFF0F172A)
val SlateTextSecondary = Color(0xFF64748B)

private val LightColorScheme = lightColorScheme(
    primary = PinkPrimary,
    onPrimary = White,
    primaryContainer = PinkLight,
    onPrimaryContainer = PinkDark,
    secondary = Color(0xFF10B981), // Emerald green for active agent
    onSecondary = White,
    background = SlateBackground,
    onBackground = SlateTextPrimary,
    surface = White,
    onSurface = SlateTextPrimary,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = SlateTextSecondary,
    outline = Color(0xFFE2E8F0)
)

@Composable
fun ShashiPrintTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography(),
        content = content
    )
}
`,
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    language: 'xml',
    category: 'Manifest',
    description: 'Android Manifest declaring required permissions, Foreground Service type, Application, and Activity',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="com.shashiprint.agent">

    <!-- 4. Permissions as requested -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
    
    <!-- Storage permissions for DownloadManager (/Download/ShashiPrint/) -->
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" 
        android:maxSdkVersion="28" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" 
        android:maxSdkVersion="32" />

    <!-- Android 13+ Notification permission -->
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <application
        android:name=".ShashiPrintApp"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.ShashiPrintAgent"
        tools:targetApi="34">

        <!-- Main Activity with Shopkeeper Login and Dashboard -->
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:theme="@style/Theme.ShashiPrintAgent"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Foreground Service for real-time Firestore listener & PrintManager -->
        <service
            android:name=".PrintForegroundService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="dataSync" />

    </application>

</manifest>
`,
  },
  {
    path: 'app/build.gradle.kts',
    name: 'app/build.gradle.kts',
    language: 'groovy',
    category: 'Gradle Build',
    description: 'App-level build.gradle with Firebase BoM 32.7.0, Jetpack Compose Material 3, WorkManager, and Coroutines',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.shashiprint.agent"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.shashiprint.agent"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // AndroidX & Core
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")

    // Jetpack Compose & Material 3 (Pink #EC4899 Theme)
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // 5. Firebase BoM 32.7.0 as requested
    implementation(platform("com.google.firebase:firebase-bom:32.7.0"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("com.google.firebase:firebase-storage-ktx")

    // WorkManager for 60s delayed file cleanup
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    // Kotlin Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")

    // Debugging tools
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
`,
  },
  {
    path: 'build.gradle.kts',
    name: 'build.gradle.kts',
    language: 'groovy',
    category: 'Gradle Build',
    description: 'Root project build.gradle configuration with Android Gradle Plugin & Google Services',
    content: `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
    id("com.google.gms.google-services") version "4.4.0" apply false
}
`,
  },
  {
    path: 'settings.gradle.kts',
    name: 'settings.gradle.kts',
    language: 'groovy',
    category: 'Gradle Build',
    description: 'Settings file declaring plugin and dependency repositories (Google, MavenCentral)',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "ShashiPrintAgent"
include(":app")
`,
  },
  {
    path: 'app/src/main/res/values/strings.xml',
    name: 'strings.xml',
    language: 'xml',
    category: 'Resources & Config',
    description: 'Android application strings and localized resources',
    content: `<resources>
    <string name="app_name">Shashi Print Agent</string>
    <string name="channel_name">Shashi Print Agent Service</string>
    <string name="channel_description">Keeps background listener active for incoming paid orders</string>
    <string name="agent_active">Agent Active - Waiting for Orders...</string>
    <string name="agent_paused">Agent Paused - Auto-Print Off</string>
</resources>
`,
  },
  {
    path: 'app/src/main/res/values/colors.xml',
    name: 'colors.xml',
    language: 'xml',
    category: 'Resources & Config',
    description: 'XML Color definitions matching Pink #EC4899 and Material 3 design',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Pink #EC4899 Primary Palette -->
    <color name="pink_500">#EC4899</color>
    <color name="pink_600">#DB2777</color>
    <color name="pink_50">#FDF2F8</color>
    <color name="white">#FFFFFF</color>
    <color name="slate_900">#0F172A</color>
    <color name="slate_600">#475569</color>
    <color name="slate_100">#F1F5F9</color>
    <color name="emerald_500">#10B981</color>
</resources>
`,
  },
  {
    path: 'google-services.json',
    name: 'google-services.json',
    language: 'json',
    category: 'Resources & Config',
    description: 'Sample Firebase Configuration file for package com.shashiprint.agent',
    content: `{
  "project_info": {
    "project_number": "718433802346",
    "project_id": "shashiprint-pos-prod",
    "storage_bucket": "shashiprint-pos-prod.appspot.com"
  },
  "client": [
    {
      "client_info": {
        "mobilesdk_app_id": "1:718433802346:android:b20df8402928394a120485",
        "android_client_info": {
          "package_name": "com.shashiprint.agent"
        }
      },
      "oauth_client": [],
      "api_key": [
        {
          "current_key": "AIzaSyB_SampleApiKeyForShashiPrintAgent1234"
        }
      ],
      "services": {
        "appinvite_service": {
          "other_platform_oauth_client": []
        }
      }
    }
  ],
  "configuration_version": "1"
}
`,
  },
  {
    path: 'README.md',
    name: 'README.md',
    language: 'markdown',
    category: 'Documentation',
    description: 'Step-by-step setup guide for compiling in Android Studio and testing with thermal printers',
    content: `# Shashi Print Agent - Android Kotlin POS App

Production-ready native Android application built with **Kotlin**, **Jetpack Compose (Material 3)**, **Firebase Auth & Firestore Real-Time Listeners**, and **Android PrintManager**.

---

## 🚀 Key Features

1. **Shopkeeper Authentication**:
   - Firebase Auth (Email & Password)
   - Persistent \`ShopID\` storage using \`SharedPreferences\`
2. **Real-time Background Service**:
   - \`PrintForegroundService\` with sticky notification: *"Shashi Print Agent - Active"*
   - Real-time Firestore snapshot listener:
     \`\`\`kotlin
     FirebaseFirestore.getInstance()
         .collection("shops").document(SHOP_ID)
         .collection("orders")
         .whereEqualTo("status", "paid")
         .whereEqualTo("printed", false)
         .addSnapshotListener { ... }
     \`\`\`
3. **Automated PDF Pipeline**:
   - Downloads order invoice PDF to \`/Download/ShashiPrint/\` via Android \`DownloadManager\`
   - Spools automatic print via Android \`PrintManager\` + custom \`PdfPrintDocumentAdapter\`
   - Updates Firestore document: \`printed = true\`, \`printedAt = FieldValue.serverTimestamp()\`
   - Schedules \`WorkManager\` (\`DeleteFileWorker\`) to safely remove the file after 60 seconds
4. **Thermal Printer & POS Compatibility**:
   - Supports USB, Bluetooth, ESC/POS, Network IP printers, and standard Android Print Spooler plugins (e.g., RawBT, ESC POS Print Service, HP Print Plugin)
5. **UI & Design**:
   - Material 3 theme in **Pink (#EC4899)** & **White**
   - Live pulsating green indicator for active agent
   - Connected printer status & Auto-Print toggle
   - Real-time list of last 5 printed orders

---

## 🛠️ How to Open & Build in Android Studio

1. Click **"Download Project (.zip)"** in the top bar.
2. Unzip the downloaded archive to your preferred folder.
3. Open **Android Studio** (Hedgehog 2023.1+ or newer recommended).
4. Choose **Open an Existing Project** and select the unzipped directory.
5. In **Firebase Console**:
   - Add an Android App with package name: \`com.shashiprint.agent\`
   - Enable **Firebase Authentication** (Email/Password)
   - Enable **Cloud Firestore** and **Firebase Storage**
   - Download your actual \`google-services.json\` and place it into \`app/google-services.json\`
6. Click **Run 'app'** (Shift + F10) on an Android device or emulator.
`,
  },
];
